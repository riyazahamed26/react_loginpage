import React, { useEffect, useState } from "react";
import MenuBookIcon from "@mui/icons-material/MenuBook";
import { useDispatch, useSelector } from "react-redux";
import { getSubject } from "../../../redux/actions/adminActions";
import { MenuItem, Select } from "@mui/material";
import Spinner from "../../../utils/Spinner";
import { SET_ERRORS } from "../../../redux/actionTypes";
import * as classes from "../../../utils/styles";

const Body = () => {
  const dispatch = useDispatch();
  const [error, setError] = useState({});
  const departments = useSelector((state) => state.admin.allDepartment);
  const [loading, setLoading] = useState(false);
  const store = useSelector((state) => state);
  const [value, setValue] = useState({
    department: "",
    year: "",
    semester: ""
  });
  const [search, setSearch] = useState(false);
  const [selectedYear, setSelectedYear] = useState('');
  const [semesters, setSemesters] = useState([]);
  const yearAvailableOptions = [1, 2, 3, 4];
  const semesterOptions = [
    { year: 1, semester: 1 },
    { year: 1, semester: 2 },
    { year: 2, semester: 3 },
    { year: 2, semester: 4 },
    { year: 3, semester: 5 },
    { year: 3, semester: 6 },
    { year: 4, semester: 7 },
    { year: 4, semester: 8 },
  ];

  const handleYearChange = (e) => {
    const selectedYear = e.target.value;
    const selYear = {...value, year: e.target.value}
    setValue(selYear)
    setSelectedYear(selectedYear);
    const filteredSemesters = semesterOptions.filter(
      (semester) => semester.year === parseInt(selectedYear)
    );
    setSemesters(filteredSemesters);
  };

  useEffect(() => {
    if (Object.keys(store.errors).length !== 0) {
      setError(store.errors);
      setLoading(false);
    }
  }, [store.errors]);

  const handleSubmit = (e) => {
    e.preventDefault();
    setSearch(true);
    setLoading(true);
    setError({});
    dispatch(getSubject(value));
  };
  const subjects = useSelector((state) => state.admin.subjects.result);

  useEffect(() => {
    if (subjects?.length !== 0) setLoading(false);
  }, [subjects]);

  useEffect(() => {
    dispatch({ type: SET_ERRORS, payload: {} });
  }, []);

  return (
    <div className="flex-[0.8] mt-3">
      <div className="space-y-5">
        <div className="flex text-gray-400 items-center space-x-2">
          <MenuBookIcon />
          <h1>All Subjects</h1>
        </div>
        <div className=" mr-10 bg-white grid grid-cols-4 rounded-xl pt-6 pl-6 h-[29.5rem]">
          <form
            className="flex flex-col space-y-2 col-span-1"
            onSubmit={handleSubmit}>
            <label htmlFor="department">Department</label>
            <Select
              required
              displayEmpty
              sx={{ height: 36, width: 224 }}
              inputProps={{ "aria-label": "Without label" }}
              value={value.department}
              onChange={(e) =>
                setValue({ ...value, department: e.target.value })
              }>
              <MenuItem value="">None</MenuItem>
              {departments?.map((dp, idx) => (
                <MenuItem key={idx} value={dp.department}>
                  {dp.department}
                </MenuItem>
              ))}
            </Select>
            
            <div>
              <label htmlFor="year">Year</label>
              <br/>
              <Select
                required
                displayEmpty
                sx={{ height: 36, width: 224 }}
                inputProps={{ "aria-label": "Without label" }}
                id="year"
                value={selectedYear}
                onChange={handleYearChange} >
                <MenuItem value={selectedYear}>Select Year</MenuItem>
                {yearAvailableOptions.map((year) => (
                  <MenuItem key={year} value={year}>
                    {`${year}`}
                  </MenuItem>
                ))}
              </Select>
            </div>
            <div>
              <label htmlFor="semester">Semester</label>
              <Select
                required
                displayEmpty
                sx={{ height: 36, width: 224 }}
                inputProps={{
                  "aria-label": "Without label"
                }}
                id="semester"
                value={value.semester}
                disabled={!selectedYear}
                onChange={(e) => setValue({ ...value, semester: e.target.value })}>
                <MenuItem value="">Select Semester</MenuItem>
                {semesters.map((semester) => (
                  <MenuItem key={`${semester.year}- ${semester.semester}`} value={semester.semester}>
                    {`${semester.semester}`}
                  </MenuItem>
                ))}
              </Select>
            </div>
            <button
              className={`${classes.adminFormSubmitButton} w-56`}
              type="submit">
              Search
            </button>
          </form>

          <div className="col-span-3 mr-6">
            <div className={classes.loadingAndError}>
              {loading && (
                <Spinner
                  message="Loading"
                  height={50}
                  width={150}
                  color="#111111"
                  messageColor="blue"
                />
              )}
              {(error.noSubjectError || error.backendError) && (
                <p className="text-red-500 text-2xl font-bold">
                  {error.noSubjectError || error.backendError}
                </p>
              )}
            </div>
            {search &&
              !loading &&
              Object.keys(error).length === 0 &&
              subjects?.length !== 0 && (
                <div className={classes.adminData}>
                  <div className="grid grid-cols-7">
                    <h1 className={`${classes.adminDataHeading} col-span-1`}>
                      Sr no.
                    </h1>
                    <h1 className={`${classes.adminDataHeading} col-span-2`}>
                      Subject Code
                    </h1>
                    <h1 className={`${classes.adminDataHeading} col-span-3`}>
                      Subject Name
                    </h1>
                    <h1 className={`${classes.adminDataHeading} col-span-1`}>
                      Total Lectures
                    </h1>
                  </div>
                  {subjects?.map((sub, idx) => (
                    <div
                      key={idx}
                      className={`${classes.adminDataBody} grid-cols-7`}>
                      <h1
                        className={`col-span-1 ${classes.adminDataBodyFields}`}>
                        {idx + 1}
                      </h1>
                      <h1
                        className={`col-span-2 ${classes.adminDataBodyFields}`}>
                        {sub.subjectCode}
                      </h1>
                      <h1
                        className={`col-span-3 ${classes.adminDataBodyFields}`}>
                        {sub.subjectName}
                      </h1>
                      <h1
                        className={`col-span-1 ${classes.adminDataBodyFields}`}>
                        {sub.totalLectures}
                      </h1>
                    </div>
                  ))}
                </div>
              )}
          </div>
        </div>
      </div >
    </div >
  );
};

export default Body;
